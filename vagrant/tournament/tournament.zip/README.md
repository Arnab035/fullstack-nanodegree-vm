- To run this program and test if it works--

-- Once terminal is set up, you need to go to the directory where vagrant is present.
-- Set up vagrant and VM( Virtual machine ) using vagrant up in the terminal.
-- Once the VM is up and running , you can use vagrant ssh to establish ssh connection.
-- if this is done, cd /vagrant/tournament
-- test the python file "tournament_test.py"(unit test file) using python tournament_test.py
-- if all tests pass, you are up and ready to go.